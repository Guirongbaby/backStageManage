import axios from "axios";
axios.defaults.headers.common["Authorization"] = "AUTH_TOKEN";

export default {
  // ① 获取登录的信息
  login(data) {
    return axios.post("/api/userlogin", data);
  }
};
