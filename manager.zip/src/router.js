import Vue from "vue";
import Router from "vue-router";
import Login from "./views/Login.vue";
import Manage from "./views/Manage.vue";
import UserManage from "./components/UserManage";
import UserTManage from "./components/UserTManage";
import RoleManage from "./components/RoleManage";
import AuthorityManage from "./components/AuthorityManage";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/",
      name: "login",
      component: Login
    },
    {
      path: "/login",
      name: "login",
      component: Login
    },
    {
      path: "/Manage",
      name: "manage",
      component: Manage,
      children: [
        {
          path: "/UserTManage",
          component: UserTManage
        },
        {
          path: "/UserManage",
          component: UserManage
        },
        {
          path: "/RoleManage",
          component: RoleManage
        },
        {
          path: "/AuthorityManage",
          component: AuthorityManage
        }
      ]
    },
    {
      path: "/about",
      name: "about",
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () =>
        import(/* webpackChunkName: "about" */ "./views/About.vue")
    }
  ]
});
