<template>
  <div class="AdminUser">
    <!-- 这是列表页面 -->
    <div class="layout">
      <!-- 整体框架部分 -->
      <Layout>
        <!-- 列表头部 -->
        <Header class="header-top">
          <p>vue 后台权限管理</p>
          <h4 @click="out">退出登录</h4>
        </Header>
        <Layout>
          <Sider
            class="sider-left"
            hide-trigger
            :style="{ background: '#fff' }"
          >
            <Menu theme="light" width="auto" :open-names="['1']">
              <Submenu name="1">
                <template slot="title">
                  <Icon type="ios-navigate"></Icon>
                  列表分配
                </template>
                <router-link to="/UserManage">
                  <MenuItem name="1-1">用户管理</MenuItem>
                </router-link>
                <router-link to="/UserTManage">
                  <MenuItem name="1-2">用户管理2</MenuItem>
                </router-link>
                <router-link to="/RoleManage">
                  <MenuItem name="1-3">角色管理</MenuItem>
                </router-link>
                <router-link to="/AuthorityManage">
                  <MenuItem name="1-3">权限管理</MenuItem>
                </router-link>
              </Submenu>
            </Menu>
          </Sider>
          <!-- <Layout :style="{ padding: '0 24px 24px' }"> -->
          <!-- <Breadcrumb :style="{ margin: '24px 0' }">
              <BreadcrumbItem>Home</BreadcrumbItem>
              <BreadcrumbItem>Components</BreadcrumbItem>
              <BreadcrumbItem>Layout</BreadcrumbItem>
            </Breadcrumb> -->
          <Content
            :style="{
              padding: '18px 0 0 0',
              minHeight: '650px',
              background: '#fff'
            }"
          >
            Content
            <router-view />
          </Content>
          <!-- </Layout> -->
        </Layout>
      </Layout>
    </div>
  </div>
</template>

<script>
export default {
  name: "Manage",
  data() {
    return {};
  },
  methods: {
    out() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped lang="scss">
.layout {
  min-height: 740px;
  border: 1px solid #d7dde4;
  background: #f5f7f9;
  position: relative;
  border-radius: 4px;
  overflow: hidden;

  .header-top {
    height: 50px;
    line-height: 50px;
    // color: white;
    p {
      font-size: 25px;
      float: left;
    }
    h4 {
      float: right;
      cursor: pointer;
    }
  }
}
.layout-logo {
  width: 100px;
  height: 30px;
  background: #5b6270;
  border-radius: 3px;
  float: left;
  position: relative;
  top: 15px;
  left: 20px;
}
.layout-nav {
  width: 420px;
  margin: 0 auto;
  margin-right: 20px;
}
.sider-left {
  height: 660px;
  .sider-l {
    background-color: white;
  }
}
</style>
