<template>
  <div class="RoleManage"></div>
</template>
<script>
export default {};
</script>

<style lang="scss" scoped></style>
