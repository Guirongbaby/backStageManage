<template>
  <div class="UserManage"></div>
</template>
<script>
export default {};
</script>

<style lang="scss" scoped></style>
